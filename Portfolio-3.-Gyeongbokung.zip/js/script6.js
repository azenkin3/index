$(function(){
  $('#learnmore').click(function(){
    $(window).scrollTop(4000);

  })
})