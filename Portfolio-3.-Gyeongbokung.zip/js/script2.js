$(function(){
    $("#hamburgermenu").hide();
})

$(function(){
    $("#hamburgernav").click(function(){
        $("#hamburgermenu").toggle();
    })
})